from rasa_core_sdk import Action
from rasa_core_sdk.events import SlotSet
from firebase_admin import auth
import pyrebase
from rasa_sdk.events import FollowupAction
from rasa_core_sdk.events import Restarted
from rasa_sdk.forms import FormAction

class name1:
    def username(self,name2):
        self.name2=name2
    def getusername(self):
        return self.name2
class number1:
    def usernumber(self,number2):
        self.number2=number2
    def getnumber(self):
        return self.number2
a=name1()
b=number1()



class greett(Action):
    def name(self):
        return "action_greet"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message("he what can i help you")
        return []

class call(Action):
    def name(self):
        return "action_call"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message("Request a call back \n -------------------------- \nPlease fill in your details below")
        return []

class name(Action):
    def name(self):
        return "action_name"

    def run(self, dispatcher, tracker, domain):
        try:
            user=tracker.get_slot('PERSON')   
            a.username(user)
            y=a.getusername()
            dispatcher.utter_message("your name is " + y)
            print(y)
        except:
            print("error")
        
        return []

class phone(Action):
    def name(self):
        return "action_phonenumber"

    def run(self, dispatcher, tracker, domain):
        try:
            phonn =tracker.get_slot('phonenumber')   
            b.usernumber(phonn)
            y1=b.getnumber()
            dispatcher.utter_message("your phone is " + y1 )
            dispatcher.utter_message("your name is "+ a.getusername() +"\n your phone is " + y1)
        except:
            print("error")
        
        return []
    
class submit(Action):
    def name(self):
        return "action_submit"

    def run(self, dispatcher, tracker, domain):        
        return [Restarted()]
    







