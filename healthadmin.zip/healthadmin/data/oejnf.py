class Bar(object):
    def __init__(self):
        self.name=" "
    def __set__(self, instance, name):
        self.name=name
    def __get__(self, instance, owner):
        return self.name
    def __delete__(self, instance):
        print("deleted in descriptor object")
        del self.name


class foo(object):
    bar=Bar()
f=foo()

f.bar="amit"
print(f.bar)
del f.bar
#print(f.bar)