import pandas as pd
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
cred = credentials.Certificate('C:/Users/amit/OneDrive/Desktop/rasainstruction/hospitalchatbot-9346d-firebase-adminsdk-wgvfq-663d979510.json')
firebase_admin.initialize_app(cred)

db = firestore.client()
doc_ref = db.collection(u'hospital_chatbot').document(u'actions1')



user_data={"users_data":{"1":{"user-info":["amit sorde","email-id","contact-detail"],
                  "visits":["2/3/2020","4/3/2020"],
                  "Doctor":"Dr.Amit",
                  "Description":"null",
                  "Appointment":"20/3/20",
                  "conversation":"Null"
                  }
               }}
doctor_data = {"1":{'Doctor':'Anuj',
        'Specialist':"Cardiology (Heart Care)",
        'Contact_detail':"Null",
        'id':"12344"
        }}
Appointment_list={"1":{"name":"user-1",
       "Doctor":"dr.amit",
       "Specialist":"Cardiology (Heart Care)",
       "Availability":"Time and date"
    }}
availability={"Availability":{"Doctor":["Dr.Amit","Dr.vikash"],
       "Specialist":["Cardiology (Heart Care)","eye"],
       "time":["Time and date","time"]
    }}


doc_ref.set({"user_data":user_data,"doctor_data":doctor_data,"availability":availability,"Appointment_list":Appointment_list})


















