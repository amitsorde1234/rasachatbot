# This files contains your custom actions which can be used to run
# custom Python code.
#
# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/custom-actions


# This is a simple example for a custom action which utters "Hello World!"

from typing import Any, Text, Dict, List

from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
import firebase_admin
from firebase_admin import credentials
from firebase_admin import auth
from firebase_admin import firestore
import requests
from requests.packages import urllib3
import pyrebase
import pandas as pd
from datetime import date 
from datetime import datetime,timedelta
from time import monotonic, sleep
print(urllib3.__file__)
print(urllib3.__version__)

firebaseConfig = {
    "apiKey": "AIzaSyAhPizzv5U4iv7eVj5Y8A6OZPSxV6Zl7Ck",
    "authDomain": "hospitalchatbot-9346d.firebaseapp.com",
    "databaseURL": "https://hospitalchatbot-9346d.firebaseio.com",
    "projectId": "hospitalchatbot-9346d",
    "storageBucket": "hospitalchatbot-9346d.appspot.com",
    "messagingSenderId": "919546343363",
    "appId": "1:919546343363:web:beed86bf39932b66ab1776",
    "measurementId": "G-T0LZM54LQ4"
  }
firebase = pyrebase.initialize_app(firebaseConfig)
auth = firebase.auth()
cred = credentials.Certificate('C:/Users/amit/OneDrive/Desktop/new/healthadmin/actions/hospital.json')
firebase_admin.initialize_app(cred) 
db = firestore.client()
doc_ref = db.collection(u'hospital_chatbot').document(u'actions1')

doc = doc_ref.get()
data=doc.to_dict()

today = date.today()
today=str(today) 
print(type(today))
da=today.split("-")
day=int(da[2])+int(1)
day=str(day)
dd=day+"/"+da[1]+"/"+da[0]


class User(object):
    def __init__(self):
        self.name=" "
    def __set__(self, instance, name):
        self.name=name
    def __get__(self, instance, owner):
        return self.name
    def __delete__(self, instance):
        print("deleted in descriptor object")
        del self.name


class username(object):
    user=User()
uname=username()

class unumber(object):
    def __init__(self):
        self.number=" "
    def __set__(self, instance, number):
        self.number=number
    def __get__(self, instance, owner):
        return self.number
    def __delete__(self, instance):
        print("deleted in descriptor object")
        del self.number

class usernumber(object):
    no=unumber()
unumber=usernumber()

del unumber.no
del uname.user

class ActionHelloWorld(Action):
    def name(self) -> Text:
        return "action_i_admin"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            try:
                person = tracker.get_slot('PERSON')
                dispatcher.utter_message(text=person+" tell your username")
            except:
                dispatcher.utter_message(text="please tell your name")
                dispatcher.utter_message(template="action_i_admin")

            return []



class use(Action):
    def name(self) -> Text:
        return "action_username"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            user1 = tracker.get_slot('user')
            uname.user=user1
            try:
                print(unumber.no)
                dispatcher.utter_message(text="you have already login with user name" +"=" +uname.user)
            except:
                dispatcher.utter_message(text=" your password please" )
            return []



class passw(Action):
    def name(self) -> Text:
        return "action_password"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            phone = tracker.get_slot('phonenumber')            
            try:
                unumber.no=phone
                password=unumber.no
                logname=uname.user
                login = auth.sign_in_with_email_and_password(logname,password) 
                #dispatcher.utter_message(text="ok "+ logname +" this are the options")
                dispatcher.utter_message("ok "+ logname +" this are the options"+"\n",buttons = [
                   {"payload":"/to_schedule", "title":"today's schedule"},{"payload": "/tomar_schedule", "title": "tomorrow's schedule"},
                   {"payload": "/user_data", "title": "patient data"},{"payload": "/update_data", "title": "update"},
                   {"payload": "/cancel_appointment", "title": "cancel appointment"},{"payload": "/reactivate", "title": "activate appointment"},
                   {"payload": "/our_information", "title": "show my data"},
                   {"payload": "/help", "title": "Help"}
                   ],button_type="reply")                
            except:
                try:
                    dispatcher.utter_message(text="there may be your username or password wrong")
                    del unumber.no
                    del uname.user
                except:
                    dispatcher.utter_message(text="please give me again first email and secound password aagin")
            return []



class today(Action):
    def name(self) -> Text:
        return "action_get_schedule"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            doc = doc_ref.get()
            try:
                unumber.no
                uname.user
                if doc.exists:
                    data=doc.to_dict()
                    x=pd.DataFrame(data['appointment_list'])
                    ###########################
                    today = date.today()
                    today=str(today) 
                    da=today.split("-")
                    dd=da[2]+"/"+da[1]+"/"+da[0]
                    dd=str(dd)
                    x=x[x["schedule"]==dd]
                    ############################
                    if x.index==None:
                        dispatcher.utter_message(text="today there is no appointment ")
                    dispatcher.utter_message(text="Date"+"______|"+"Time"+"____|"+"Name"+"_|"+"Status")
                    for i in x.index:
                        dispatcher.utter_message(text=x["schedule"][i]+"|"+"-"+"|"+x["Time"][i]+"|"+"-"+"|"+x["name"][i]+"|"+"-"+x["status"][i])
                    dispatcher.utter_message(text="-----",buttons = [
                   {"payload":"/to_schedule", "title":"today's schedule"},{"payload": "/tomar_schedule", "title": "tomorrow's schedule"},
                   {"payload": "/user_data", "title": "patient data"},{"payload": "/update_data", "title": "update"},
                   {"payload": "/cancel_appointment", "title": "cancel appointment"},{"payload": "/reactivate", "title": "activate appointment"},
                   {"payload": "/our_information", "title": "show my data"},
                   {"payload": "/help", "title": "Help"}
                   ],button_type="reply")
                else:
                    print(u'No such document!')           
            except:
                dispatcher.utter_message(text="please login to get the data first give username and password")
                       
            return []

class tomarro(Action):
    def name(self) -> Text:
        return "action_get_tomarro_schedule"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            doc = doc_ref.get()
            try:
                unumber.no
                uname.user              
                data=doc.to_dict()
                x=pd.DataFrame(data['appointment_list'])
                today = date.today()
                today=str(today) 
                da=today.split("-")
                day=int(da[2])+int(1)
                day=str(day)
                dd=day+"/"+da[1]+"/"+da[0]
                y=x[x["schedule"]==dd]
                if y.index==None:
                    dispatcher.utter_message(text="tomarrow there is no appointment")

                dispatcher.utter_message(text="Date"+"______|"+"Time"+"____|"+"Name"+"_|"+"Status")
                for i in y.index:
                    dispatcher.utter_message(text=x["schedule"][i]+"|"+"-"+"|"+x["Time"][i]+"|"+"-"+"|"+x["name"][i]+"|"+"-"+x["status"][i])
                dispatcher.utter_message(text="-----",buttons = [
                   {"payload":"/to_schedule", "title":"today's schedule"},{"payload": "/tomar_schedule", "title": "tomorrow's schedule"},
                   {"payload": "/user_data", "title": "patient data"},{"payload": "/update_data", "title": "update"},
                   {"payload": "/cancel_appointment", "title": "cancel appointment"},{"payload": "/reactivate", "title": "activate appointment"},
                   {"payload": "/our_information", "title": "show my data"},
                   {"payload": "/help", "title": "Help"}
                   ],button_type="reply")
            except:
                dispatcher.utter_message(text="please login to get the data first give username and password")
            return []


class user_da(Action):
    def name(self) -> Text:
        return "action_user_data"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            doc = doc_ref.get()
            try:
                unumber.no
                uname.user
                if doc.exists:
                    data=doc.to_dict()
                    #print(data['user_data'])
                    x=pd.DataFrame(data['user_data'])
                    data=[]
                    for i in x.keys():
                         data.append([i,"=",x[i][0]])
                    dat=pd.DataFrame(data)
                    dispatcher.utter_message(text="Name"+"|"+"Email id"+"|"+"appoint."+"|"+"Dr."+"|"+"Visits")

                    for i in range(0,len(x)):
                        dispatcher.utter_message(text=x["name"][i]+"|-|"+x["email_id"][i]+"|-|"+x["appointment"][i]+"|-|"+x["doctor"][i]+"|-|"+x["visits"][i])             
                    dispatcher.utter_message(text="-------",buttons = [
                   {"payload":"/to_schedule", "title":"today's schedule"},{"payload": "/tomar_schedule", "title": "tomorrow's schedule"},
                   {"payload": "/user_data", "title": "patient data"},{"payload": "/update_data", "title": "update"},
                   {"payload": "/cancel_appointment", "title": "cancel appointment"},{"payload": "/reactivate", "title": "activate appointment"},
                   {"payload": "/our_information", "title": "show my data"},
                   {"payload": "/help", "title": "Help"}
                   ],button_type="reply")    
                else:
                    print(u'No such document!')           
            except:
                dispatcher.utter_message(text="please login to get the data")
            return []

class updatee(Action):
    def name(self) -> Text:
        return "action_update"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            doc = doc_ref.get()
            data=doc.to_dict()
            try:
                print(unumber.no)
                print(uname.user)
                dispatcher.utter_message(text="you can update your name ,modile number \n example \n 1. change my name n_NAME \n 2. change my number _NUMBER")
                data=data["doctor_list"]
                data=pd.DataFrame(data)
                for i in range(0,len(data)):
                         dispatcher.utter_message(text=data["specialist"][i]+"|-|"+data["contact_detail"][i]+"|-|"+data["Doctor"][i])
            except:
                dispatcher.utter_message(text="please login to update") 
            return []


class upname(Action):
    def name(self) -> Text:
        return "action_change_name"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            doc = doc_ref.get()
            try:
                unumber.no
                uname.user
                phone = tracker.get_slot('upname')
                namee=phone.split("_")
                try:
                    doc_ref.update({"doctor_list.Doctor":[namee[1]]})           
                    dispatcher.utter_message("your name is changed",buttons = [
                   {"payload": "/our_information", "title": "check the changes"}
                   ])
                except:
                    dispatcher.utter_message(text="you are giving new name in wrong fromate\n type n_NEW NAME")
            except:       
                dispatcher.utter_message(text="please login to update")                 
            return []

class number(Action):
    def name(self) -> Text:
        return "action_change_number"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            try:
                unumber.no
                uname.user
                phone = tracker.get_slot('upnumber')
                namee=phone.split("_")
                
                try:
                    doc_ref.update({"doctor_list.contact_detail":[namee[1]]})
                    dispatcher.utter_message("your mobile number is changed",buttons = [
                   {"payload": "/our_information", "title": "check the changes"}
                   ])
                except:
                    dispatcher.utter_message(text="you are giving new name in wrong fromate\n type _number")
            except:       
                dispatcher.utter_message(text="please login to update") 
            return []

class appoint(Action):
    def name(self) -> Text:
        return "action_appointment"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            try:
                unumber.no
                uname.user
                dispatcher.utter_message(text="For canceling the appointment type \n 1. cancel_23/12/2021(day/month/year) \n 2. cancel_4.00_pm(Time of appointment) \n 3. 26/12/2021_4/12/2021(month/day/year)")
            except:       
                dispatcher.utter_message(text="please login to update") 
            return []

class user_id(Action):
    def name(self) -> Text:
        return "action_appointment_user_id"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            doc = doc_ref.get()
            data=doc.to_dict()
            try:
                unumber.no
                uname.user
                user = tracker.get_slot('user_id')
                user=user.split("_")
                print("1")
                try:
                    appoi=data["appointment_list"]
                    appoi=pd.DataFrame(appoi)
                    appoi["status"].loc[appoi["user_id"]==user[1]]="cancel"
                    appo={"name":list(appoi["name"]),"user_id":list(appoi["user_id"]),"Doctor":list(appoi["Doctor"]),"Specialist":list(appoi["Specialist"]),"schedule":list(appoi["schedule"]),"Time":list(appoi["Time"]),"status":list(appoi["status"])}
                    doc_ref.update({"appointment_list":appo})
                    dispatcher.utter_message(text="appointment of user id_"+user[1] +"_is cancel")
                    for i in range(0,len(appoi)):
                        dispatcher.utter_message(text="NAME"+"="+appoi["name"][i]+"\n"+"-------------"+"\n"+"USER_ID"+"="+appoi["user_id"][i]+"\n"+"-------------"+"\n"+"DOCTOR"+"="+appoi["Doctor"][i]+"\n"+"-------------"+"\n"+"SPECIALIST"+"="+appoi["Specialist"][i]+"\n"+"-------------"+"\n"+"SCHEDULE"+"="+appoi["schedule"][i]+"\n"+"-------------"+"\n"+"TIME"+"="+appoi["Time"][i]+"\n"+"-------------"+"\n"+"STATUS"+"="+appoi["status"][i]+"\n"+"----------------------")
                except:
                    dispatcher.utter_message(text="you have enter wrong user id")
            except:       
                dispatcher.utter_message(text="please login to update") 
            return []


class user_id(Action):
    def name(self) -> Text:
        return "action_appointment_user_name"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            doc = doc_ref.get()
            data=doc.to_dict()
            try:
                unumber.no
                uname.user
                user = tracker.get_slot('user_name')
                user=user.split("_")
                try:
                    appoi=data["appointment_list"]
                    appoi=pd.DataFrame(appoi)
                    appoi["status"].loc[appoi["name"]==user[2]]="cancel"
                    appo={"name":list(appoi["name"]),"user_id":list(appoi["user_id"]),"Doctor":list(appoi["Doctor"]),"Specialist":list(appoi["Specialist"]),"schedule":list(appoi["schedule"]),"Time":list(appoi["Time"]),"status":list(appoi["status"])}
                    doc_ref.update({"appointment_list":appo})
                    dispatcher.utter_message(text="appointment with name"+user[2] +" is cancel")
                    for i in range(0,len(appoi)):
                        dispatcher.utter_message(text="NAME"+"="+appoi["name"][i]+"\n"+"-------------"+"\n"+"USER_ID"+"="+appoi["user_id"][i]+"\n"+"-------------"+"\n"+"DOCTOR"+"="+appoi["Doctor"][i]+"\n"+"-------------"+"\n"+"SPECIALIST"+"="+appoi["Specialist"][i]+"\n"+"-------------"+"\n"+"SCHEDULE"+"="+appoi["schedule"][i]+"\n"+"-------------"+"\n"+"TIME"+"="+appoi["Time"][i]+"\n"+"-------------"+"\n"+"STATUS"+"="+appoi["status"][i]+"\n"+"----------------------")
                except:
                    dispatcher.utter_message(text="you have enter wrong user id")
            except:       
                dispatcher.utter_message(text="please login to update") 
            return []

class user_id(Action):
    def name(self) -> Text:
        return "action_appointment_user_date"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            doc = doc_ref.get()
            data=doc.to_dict()
            try:
                unumber.no
                uname.user
                user = tracker.get_slot('date')
                user=user.split("_")
                print(user[1])
                try:
                    appoi=data["appointment_list"]
                    appoi=pd.DataFrame(appoi)
                    appoi["status"].loc[appoi["schedule"]==user[1]]="cancel"
                    appo={"name":list(appoi["name"]),"user_id":list(appoi["user_id"]),"Doctor":list(appoi["Doctor"]),"Specialist":list(appoi["Specialist"]),"schedule":list(appoi["schedule"]),"Time":list(appoi["Time"]),"status":list(appoi["status"])}
                    doc_ref.update({"appointment_list":appo})
                    dispatcher.utter_message(text="appointment at date_"+user[1]+"_is cancel")
                    dispatcher.utter_message(text="Date"+"______|"+"Time"+"____|"+"Name"+"_|"+"Status")
                    for i in range(0,len(appoi)):                       
                        dispatcher.utter_message(text=appoi["schedule"][i]+"|-|"+appoi["Time"][i]+"|-|"+appoi["name"][i]+"|-|"+appoi["status"][i])

                except:
                    dispatcher.utter_message(text="you have enter wrong user id")
            except:       
                dispatcher.utter_message(text="please login to update") 
            return []


class between(Action):
    def name(self) -> Text:
        return "action_appointment_between_date"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            doc = doc_ref.get()
            data=doc.to_dict()
            try:
                unumber.no
                uname.user
                try:
                    user = tracker.get_slot('date1')
                    user=user.split("_")
                    print(user)
                    today = date.today()
                    try:
                        date1=user[0].split("/")
                        date2=user[1].split("/") 
                        try:
                            a1 = datetime(int(date1[2]), int(date1[1]), int(date1[0]))
                            a2 = datetime(int(date2[2]), int(date2[1]), int(date2[0]))
                            print(a1.timestamp())
                            ti=a1.timestamp()
                            print(a2.timestamp())
                            ti1=a2.timestamp()
                            if ti<=ti1:
                                appoi=data["appointment_list"]
                                appoi=pd.DataFrame(appoi)
                                for i in appoi["schedule"]:
                                    dat=i.split("/")
                                    x=datetime(int(dat[2]), int(dat[1]), int(dat[0]))
                                    if ti<=x.timestamp()<=ti1:
                                        appoi["status"].loc[appoi["schedule"]==i]="cancel"   
                                        appo={"name":list(appoi["name"]),"user_id":list(appoi["user_id"]),"Doctor":list(appoi["Doctor"]),"Specialist":list(appoi["Specialist"]),"schedule":list(appoi["schedule"]),"Time":list(appoi["Time"]),"status":list(appoi["status"])}
                                        doc_ref.update({"appointment_list":appo}) 
                                dispatcher.utter_message(text="all appointment are cancel")
                                dispatcher.utter_message(text="Date"+"______|"+"Time"+"____|"+"Name"+"_|"+"Status")
                                for i in range(0,len(appoi)):                       
                                    dispatcher.utter_message(text=appoi["schedule"][i]+"|-|"+appoi["Time"][i]+"|-|"+appoi["name"][i]+"|-|"+appoi["status"][i])

                            else:
                                dispatcher.utter_message(text="date1 must be lower than date2 \n date1_date2")
                        except:
                                dispatcher.utter_message(text="Give the date in proper formate \n example:- \n day/month/year_day/month/year")
                    except:
                        dispatcher.utter_message(text="please give the _ between the date")
                except:
                    dispatcher.utter_message(text="please give the _ between the date")
            except:
                dispatcher.utter_message(text="please login to cancel")
            return []

class betweentime(Action):
    def name(self) -> Text:
        return "action_appointment_time_between"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            doc = doc_ref.get()
            data=doc.to_dict()
            try:
                unumber.no
                uname.user
                try:
                    user = tracker.get_slot('time1')
                    user=user.split("_")
                    use=user[1].split(".")
                    print(use)                                    
                except:
                    dispatcher.utter_message(text="please give the time in proper formate time1_time2")                                        
            except:
                dispatcher.utter_message(text="please login to cancel")
            return []



class user_id(Action):
    def name(self) -> Text:
        return "action_appointment_user_time"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            doc = doc_ref.get()
            data=doc.to_dict()
            try:
                unumber.no
                uname.user
                try:
                    user = tracker.get_slot('time')
                    user=user.split("_")
                    tim=user[1]+user[2]
                    if len(user)==3:
                        appoi=data["appointment_list"]
                        appoi=pd.DataFrame(appoi)
                        appoi["status"].loc[appoi["Time"]==tim]="cancel"
                        appo={"name":list(appoi["name"]),"user_id":list(appoi["user_id"]),"Doctor":list(appoi["Doctor"]),"Specialist":list(appoi["Specialist"]),"schedule":list(appoi["schedule"]),"Time":list(appoi["Time"]),"status":list(appoi["status"])}
                        doc_ref.update({"appointment_list":appo})
                        dispatcher.utter_message(text="appointment at time"+user[1]+"_"+user[2]+"is cancel")
                        dispatcher.utter_message(text="Date"+"______|"+"Time"+"____|"+"Name"+"_|"+"Status")
                        for i in range(0,len(appoi)):
                            dispatcher.utter_message(text=appoi["schedule"][i]+"|-|"+appoi["Time"][i]+"|-|"+appoi["name"][i]+"|-|"+appoi["status"][i])

                    else:
                        dispatcher.utter_message(text="please enter the proper formate \n example\n cancel_6.00_am")
                except:
                    dispatcher.utter_message(text="please enter the proper formate \n example\n cancel_6.00_am")
            except:
                dispatcher.utter_message(text="please login to cancel")
            return []


class info_my(Action):
    def name(self) -> Text:
        return "action_our_information"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            doc = doc_ref.get()
            data=doc.to_dict()
            try:
                unumber.no
                uname.user
                data=data["doctor_list"]
                data=pd.DataFrame(data)
                for i in range(0,len(data)):
                         dispatcher.utter_message(text=data["specialist"][i]+"|-|"+data["contact_detail"][i]+"|-|"+data["Doctor"][i])
                dispatcher.utter_message(text="-----------",buttons = [
                   {"payload":"/to_schedule", "title":"today's schedule"},{"payload": "/tomar_schedule", "title": "tomorrow's schedule"},
                   {"payload": "/user_data", "title": "patient data"},{"payload": "/update_data", "title": "update"},
                   {"payload": "/cancel_appointment", "title": "cancel appointment"},{"payload": "/reactivate", "title": "activate appointment"},
                   {"payload": "/our_information", "title": "show my data"},
                   {"payload": "/help", "title": "Help"}
                   ],button_type="reply")         
            except:
                dispatcher.utter_message(text="please login to get your information")
            return []

######reactivate#######
class reactiva(Action):
    def name(self) -> Text:
        return "action_reactivate"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            doc = doc_ref.get()
            data=doc.to_dict()
            try:
                unumber.no
                uname.user
                dispatcher.utter_message(text="For activate the appointment type \n 1. activate_23/12/2021(day/month/year) \n 2. activate_4.00_pm(Time of appointment) ")
            except:
                dispatcher.utter_message(text="please login to reactivate")
            return []





class activate_date(Action):
    def name(self) -> Text:
        return "action_reactivate_appointment_date"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            doc = doc_ref.get()
            data=doc.to_dict()
            try:
                unumber.no
                uname.user
                try:
                    
                    user = tracker.get_slot('activate_date')
                    user=user.split("_")
                    print(user[1])
                    try:
                        appoi=data["appointment_list"]
                        appoi=pd.DataFrame(appoi)
                        appoi["status"].loc[appoi["schedule"]==user[1]]="active"
                        appo={"name":list(appoi["name"]),"user_id":list(appoi["user_id"]),"Doctor":list(appoi["Doctor"]),"Specialist":list(appoi["Specialist"]),"schedule":list(appoi["schedule"]),"Time":list(appoi["Time"]),"status":list(appoi["status"])}
                        doc_ref.update({"appointment_list":appo})
                        dispatcher.utter_message(text="appointment at date_"+user[1]+"_is cancel")
                        dispatcher.utter_message(text="Date"+"______|"+"Time"+"____|"+"Name"+"_|"+"Status")
                        for i in range(0,len(appoi)):
                            dispatcher.utter_message(text=appoi["schedule"][i]+"|-|"+appoi["Time"][i]+"|-|"+appoi["name"][i]+"|-|"+appoi["status"][i])

                    except:
                        dispatcher.utter_message(text="you have enter wrong user id")               
                except:
                    dispatcher.utter_message(text="please give the _ between the date")
            except:
                dispatcher.utter_message(text="please login to cancel")
            return []

class activate_time(Action):
    def name(self) -> Text:
        return "action_activate_appointment_time"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            doc = doc_ref.get()
            data=doc.to_dict()
            try:
                unumber.no
                uname.user
                user = tracker.get_slot('atime')
                user=user.split("_")
                print(user[1])
                datee=user[1]+user[2]
                try:
                    appoi=data["appointment_list"]
                    appoi=pd.DataFrame(appoi)
                    appoi["status"].loc[appoi["Time"]==datee]="active"
                    appo={"name":list(appoi["name"]),"user_id":list(appoi["user_id"]),"Doctor":list(appoi["Doctor"]),"Specialist":list(appoi["Specialist"]),"schedule":list(appoi["schedule"]),"Time":list(appoi["Time"]),"status":list(appoi["status"])}
                    doc_ref.update({"appointment_list":appo})
                    dispatcher.utter_message(text="appointment at date_"+user[1]+"_is active")
                    dispatcher.utter_message(text="Date"+"______|"+"Time"+"____|"+"Name"+"_|"+"Status")
                    for i in range(0,len(appoi)):                       
                        dispatcher.utter_message(text=appoi["schedule"][i]+"|-|"+appoi["Time"][i]+"|-|"+appoi["name"][i]+"|-|"+appoi["status"][i])

                except:
                    dispatcher.utter_message(text="you have enter wrong user id")
            except:       
                dispatcher.utter_message(text="please login to update") 
            return []

class signouu(Action):
    def name(self) -> Text:
        return "action_signout"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            try:
                del unumber.no
                del uname.user
            except:
                dispatcher.utter_message(text="to signout first login")
            return []


class help(Action):
    def name(self) -> Text:
        return "action_help"
    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
            helpp="Hi, welcome to telegram service \n start the session login \n end the session signout \n you can get \n-----------------\n 1. todays timetable \n 2. tomorrow timeble\n 3. user data(patient name) \n 4. admin data \n you can update your \n-----------------\n 1. name \n 2. mobile number \n example \n -i want to change my name n_new name(n_yachana) \n -i want to change my number _new number(_98282)\n-----------------\ncancel the apointment \n 1. cancel_23/12/2021(day/month/year)\n 3. 23/2/2021_22/12/2021(day/month/year) \n 3. Cancel_4.00_pm(Time of appointment)"
            dispatcher.utter_message(text=str(helpp))
            dispatcher.utter_message(text="-----------",buttons = [
                   {"payload":"/to_schedule", "title":"today's schedule"},{"payload": "/tomar_schedule", "title": "tomorrow's schedule"},
                   {"payload": "/user_data", "title": "patient data"},{"payload": "/update_data", "title": "update"},
                   {"payload": "/cancel_appointment", "title": "cancel appointment"},{"payload": "/reactivate", "title": "activate appointment"},
                   {"payload": "/our_information", "title": "show my data"},
                   {"payload": "/help", "title": "Help"}
                   ],button_type="reply")         
            return []
