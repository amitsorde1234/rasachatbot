## intent:greet
- hey
- hello there
- hi
- good morning
- good evening
- hey there
- hey dude

## intent:goodbye
- cu
- good by
- cee you later
- good night
- good afternoon
- bye
- goodbye
- have a nice day
- bye bye
- see you later
  
## intent: my_username
- [amit](PERSON) is my full name
- [sangmitra](PERSON) my full name
- [ramesh](PERSON) full name
- [kumal](PERSON) is latest full name
- my full name is [sunita](PERSON)
- full name [akash](PERSON)
- [ankit](PERSON)
- [vikash](PERSON)
- [mahadev](PERSON)
- [suman](PERSON)
- [shanti](PERSON)
- [swaraj](PERSON)
- [jini](PERON)
- [pooja](PERSON)
- [mina][PERSON]
- my old full name is [vandana](PERSON)
- my current full name is [vinod](PERSON)
- [simran](PERSON) is my full name
- full name [rekha](PERSON)
- my only full name is [bipin](PERSON)
- my name is [rakesh](PERSON)
- [rakesh](PERSON) is my name
- my full name is [rakesh](PERSON)
- my only name is [raskesh](PERSON)
- MY only full name is [raskesh](person)

## intent: phonenumber
- my phonenumber [1234556787](phonenumber)
- phonenumber [2735297636](phonenumber)
- [9992833233](phonenumber)
- [9808753407](phonenumber) is my phone number
- my number is [9873038303](phonenumber)
- number is [8729873849](phonenumber)
- my phone is [1238339220](phonenumber)
- phone is [1123123332](phonenumber)
- [1231222332](phonenumber) is only number
- my only number is [1223456789](phonenumber)
- my old number is [1927321981](phonenumber)
- my new number is [9862826181](phonenumber)
- [1123876383](phonenumber) is my old number
- [1239836383](phonenumber) is my new number
- [1273528292](phonenumber) is my recent number

## intent: bot_challenge
- are you a bot ?
- are you a human ?
- am I talking to a bot ?
- am I talking to a human ?


## intent: GET_A_QUOTE
- get a quote
- get_a_quote
- GET_A_QUOTE
- GET A QUOTE
- get
- a quote
- quote
- getaquote
- Quote
- quote please
  